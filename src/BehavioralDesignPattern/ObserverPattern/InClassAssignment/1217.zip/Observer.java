package BehavioralDesignPattern.ObserverPattern.InClassAssignment;

public abstract class Observer {
    public abstract void update(FileInfo fileInfo);
}
