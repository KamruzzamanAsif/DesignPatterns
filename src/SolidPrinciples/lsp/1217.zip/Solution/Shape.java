package SolidPrinciples.lsp.Solution;

public interface Shape {
    double getArea();
}
