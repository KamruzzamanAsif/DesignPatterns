package DesignPattern.AbstractFactory;

public class MotifWindow extends Window {
}
