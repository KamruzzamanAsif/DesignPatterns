package DesignPattern.AbstractFactory;

public class PMScrollbar extends Scrollbar {
}
