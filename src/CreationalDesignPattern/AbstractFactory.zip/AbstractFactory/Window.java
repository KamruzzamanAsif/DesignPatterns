package DesignPattern.AbstractFactory;

public class Window {
}
