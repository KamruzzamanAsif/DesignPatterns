package DesignPattern.AbstractFactory;

public class MotifScrollbar extends Scrollbar {
}
