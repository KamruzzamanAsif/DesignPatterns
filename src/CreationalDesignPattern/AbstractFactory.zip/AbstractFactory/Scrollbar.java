package DesignPattern.AbstractFactory;

public class Scrollbar {
}
