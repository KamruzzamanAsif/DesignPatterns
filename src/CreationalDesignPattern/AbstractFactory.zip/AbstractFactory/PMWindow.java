package DesignPattern.AbstractFactory;

public class PMWindow extends Window {
}
