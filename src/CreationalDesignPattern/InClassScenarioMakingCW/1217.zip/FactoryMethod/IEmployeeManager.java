package DesignPattern.InClassScenarioMakingCW.FactoryMethod;

public interface IEmployeeManager {
    double getBonus();
    double getHourlyPay();
}
