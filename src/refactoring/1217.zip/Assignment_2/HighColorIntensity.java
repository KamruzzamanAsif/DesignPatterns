package refactoring.Assignment_2;

public class HighColorIntensity extends ColorIntensity{
}
