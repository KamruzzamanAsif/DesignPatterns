package refactoring.Assignment_2;

public class PageSaveMode extends PrintMode{
    public PageSaveMode(PrintModeProperties printModeProperties) {
        super(printModeProperties);
    }

    @Override
    public void applyConfiguration() {
        // algorithm to change pageSize, orientation
    }
}
