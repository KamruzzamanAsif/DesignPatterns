package refactoring.Assignment_2;

public class RenderPreview {
    public void preview(Document document){
        // preview the document
    }
}
