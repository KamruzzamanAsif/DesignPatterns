package refactoring.Assignment_2;

public class PageSize {
    double height;
    double width;

    public PageSize(double height, double width){
        this.height = height;
        this.width = width;
    }
}
