package refactoring.Assignment_2;

public abstract class ColorIntensity {
}
