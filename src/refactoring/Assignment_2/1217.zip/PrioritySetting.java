package refactoring.Assignment_2;

import refactoring.Scenario.PrintRequest;

public class PrioritySetting {
    public void changePriority(PrintRequest request, int newPriority) {
        // change the priority of the given PrintRequest
    }
}
