package DesignPattern.Scenario.FactoryMethod;

import DesignPattern.Scenario.FactoryMethod.IEmployeeManager;

public class ContractEmployeeManager implements IEmployeeManager {
    @Override
    public double getBonus() {
        return 500;
    }

    @Override
    public double getHourlyPay() {
        return 100;
    }
}
